# Linear Regression With ScikitLearn
This repository provides an introduction to Linear Regression using `ScikitLearn`.

# Setup
**Clone or download** the repository.
```
$ git clone https://github.com/tanlitung/Notebook-Linear-Regression-Sklearn.git
$ cd Notebook-Linear-Regression-Sklearn
```

# Additional Material
To learn more about regression with ScikitLearn, visit the [official documentation](https://scikit-learn.org)
